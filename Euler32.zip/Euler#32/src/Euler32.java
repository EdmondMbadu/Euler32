import java.util.ArrayList;

public class Euler32 {
	
	public static void main(String[]args) {
		ArrayList<Integer>answer= new ArrayList<>();
		String term="";
		int t=0;
		//int l=Lenght("12343", 0, 1,1);System.out.println(l);
		for(int i=10; i<1000; i++) {
			for(int j=10; j<1000; j++) {
				int value= i*j;
				 term=Integer.toString(i)+Integer.toString(j)+Integer.toString(value);
				
				for(int k=1; k<=term.length(); k++) {
					
					if(term.contains(Integer.toString(k))) t++;
					if(k==9)k=1;
					
				}
				if(t==9 && !answer.contains(value)) {
					answer.add(value);
				}
				term ="";
				t=0;
			}
			term ="";
			t=0;
		
		}
		//System.out.println(answer);
		int sum=0;
		for(int i=0; i<answer.size(); i++)sum+=answer.get(i);
		System.out.println(sum);
		System.out.println(answer.size());
	}
	
	public static int Lenght(String letters, int i, int contain, int t) {
		if(i==letters.length())return contain;
		else {
			if(letters.contains(Integer.toString(i))){
				contain++;
				t++;
				//if(i==9)i=1;
				i++;
				return Lenght(letters, i, contain,t);
			}
			else {
				i++;
				t++;
				return Lenght(letters, i, contain,t);
				
				
			}
		}
	}

}
